# Dependency Rule: ORM mapping lives in the outermost layer and maps to/from the plain entity.
from datetime import datetime

from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from transcript_requester.entities.transcript_request import TranscriptRequest


class Base(DeclarativeBase):
    pass


class TranscriptRequestRecord(Base):
    __tablename__ = "transcript_requests"

    id: Mapped[str] = mapped_column(primary_key=True)
    source_url: Mapped[str]
    requested_at: Mapped[datetime]
    status: Mapped[str] = mapped_column(default="requested")

    @classmethod
    def from_entity(cls, entity: TranscriptRequest) -> "TranscriptRequestRecord":
        return cls(
            id=entity.id,
            source_url=entity.source_url,
            requested_at=entity.requested_at,
            status=entity.status,
        )

    def to_entity(self) -> TranscriptRequest:
        return TranscriptRequest(
            id=self.id,
            source_url=self.source_url,
            requested_at=self.requested_at,
            status=self.status,  # type: ignore[arg-type]
        )
