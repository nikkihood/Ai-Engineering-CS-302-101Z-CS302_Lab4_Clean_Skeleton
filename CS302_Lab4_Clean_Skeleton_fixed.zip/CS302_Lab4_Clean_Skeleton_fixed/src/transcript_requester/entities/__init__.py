"""Entity definitions."""
